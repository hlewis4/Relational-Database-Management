/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package actionPackage;

import DbPack.TrippleDes;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Date;

/**
 *
 * @author jp
 */
@WebServlet("/add_project_title")
public class add_project_title extends HttpServlet {
    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String timeslot = null;
            String user = request.getParameter("title");
            String fname = request.getParameter("fname");
            String number = request.getParameter("number");
            
            String group = request.getParameter("group");
            
            /*if(group.equals("ECE")){
                timeslot ="1";
               }
            else if(group.equals("CSE")){
                timeslot ="2";
            }
            else if(group.equals("IT")){
                timeslot ="2";
            }
            else if(group.equals("MECH")){
                timeslot ="2";
            }
            else if(group.equals("CIVIL")){
                timeslot ="2";
            }
            else if(group.equals("EEE")){
                timeslot ="2";
            }
            else{
                 timeslot ="3";   
                }
            if(pass.equals(conpass)){*/
            Connection con  =DbPack.DatabaseConnection.getCon();
            Statement st = con.createStatement();
            String status="Available";
            int i = st.executeUpdate("insert into project_titles(title,branch,status,fname,number) values('"+user+"','"+group+"','"+status+"','"+fname+"','"+number+"')"); 
            
             //if(i!=0){
                 //mail_Send.sendMail(new TrippleDes().encrypt(group), user, email);
                 
                 response.sendRedirect("select_group.jsp?m=Registeration done");
                 System.out.println("Registeration done");
             //}
             //else{
                   //response.sendRedirect("register.jsp?m=register error...check");
             //}
            //}
            //else{
                //response.sendRedirect("register.jsp?m=password not match");
            //}
        } catch (Exception ex) {
            Logger.getLogger(add_project_title.class.getName()).log(Level.SEVERE, null, ex);
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(add_project_title.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(add_project_title.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
